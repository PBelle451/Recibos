import 'package:recibos/model/professional.dart';
import 'package:recibos/model/receipt.dart';
import 'package:recibos/model/user.dart';

class AccountantReport {
  final DateTime date;
  final Worker worker;
  final User user;
  List<Receipt> receipts = [];

  AccountantReport(
      {required this.date,
      required this.worker,
      required this.user,
      required this.receipts});
}
