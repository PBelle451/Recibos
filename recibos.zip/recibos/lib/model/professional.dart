class Worker {
  final String name;
  final String cpf;
  final String crm;
  final String signature;

  Worker(
      {required this.name,
      required this.cpf,
      required this.crm,
      required this.signature});
}
