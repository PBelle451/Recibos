import 'package:recibos/model/patient.dart';
import 'package:recibos/model/receipt.dart';
import 'package:recibos/model/user.dart';

class PatientReport {
  final Patient patient;
  final DateTime date;
  final User user;
  final List<Receipt> receipts = [];

  PatientReport(
      {required this.user, required this.date, required this.patient});
}
