class Patient {
  final String name;
  final String rg;
  final String cpf;
  final String endereco;

  Patient(
      {required this.name,
      required this.rg,
      required this.cpf,
      required this.endereco});
}
