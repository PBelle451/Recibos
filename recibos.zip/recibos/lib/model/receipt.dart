import 'package:recibos/model/patient.dart';
import 'package:recibos/model/professional.dart';
import 'package:recibos/model/user.dart';

class Receipt {
  final User user;
  Worker worker;
  Patient pacient;
  DateTime date;
  String description;
  int numberOfSessions;
  double value;

  Receipt(
      {required this.user,
      required this.worker,
      required this.pacient,
      required this.date,
      required this.description,
      required this.numberOfSessions,
      required this.value});
}
