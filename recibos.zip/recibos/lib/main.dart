import 'package:firebase_ui_auth/firebase_ui_auth.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:recibos/provider/receipts_provider.dart';
import 'package:recibos/screen/home_screen.dart';
import 'package:recibos/screen/new_receipt_screen.dart';
import 'package:recibos/screen/receipts_by_customer.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider<ReceiptsProvider>(
            create: (context) => ReceiptsProvider())
      ],
      child: MaterialApp(
        title: 'Flutter Demo',
        theme: ThemeData(
          primarySwatch: Colors.blue,
        ),
        routes: {
          HomeScreen.routeName: (context) => const HomeScreen(title: "Recibos"),
          NewReceiptScreen.routeName: (context) => const NewReceiptScreen(),
          ReceiptsByCustomerScreen.routeName: (context) => const ReceiptsByCustomerScreen(),
          "/sign-in": (context) => SignInScreen(
                providers: [
                  EmailAuthProvider(),
                ],
              )
        },
      ),
    );
  }
}
