import 'package:flutter/foundation.dart';
import 'package:recibos/model/receipt.dart';

class ReceiptsProvider with ChangeNotifier {
  List<Receipt> _receipts = <Receipt>[];
  List<Receipt> get receipts => _receipts;
  set receipts(List<Receipt> value) {
    _receipts = value;
    notifyListeners();
  }
}
