import 'package:flutter/material.dart';

class NewReceiptScreen extends StatelessWidget {
  const NewReceiptScreen({Key? key}) : super(key: key);
  static const String routeName = "/newReceipt";
  static const String title = "Novo recibo";
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(title: const Text(title)), body: const Placeholder());
  }
}
