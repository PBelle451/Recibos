import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:recibos/provider/receipts_provider.dart';

class ReceiptsByCustomerScreen extends StatelessWidget {
  static const String routeName = "/receiptsByCustomer";
  const ReceiptsByCustomerScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          key: const Key("AppbarTelaReceiptsByCustomerScreen"),
          title: const Text("Lista de Recibos"),
        ),
        body: Consumer<ReceiptsProvider>(
            builder: (BuildContext context, ReceiptsProvider provider,
                Widget? child) =>
                ListView.builder(
                    key: const Key("ReceiptsList"),
                    itemCount: provider.receipts.length,
                    itemBuilder: (context, index) {
                      return ListTile(
                        title: Text(provider.receipts
                            .elementAt(index)
                            .date
                            .toIso8601String()),
                      );
                    })));
  }
}
