import 'package:flutter/material.dart';

class LoginScreen extends StatelessWidget {
  const LoginScreen({Key? key}) : super(key: key);
  static const String routeName = "/login";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Column(
      children: [
        TextFormField(
          key: const Key("LoginField"),
        ),
        TextFormField(
          key: const Key("PasswordField"),
        ),
      ],
    ));
  }
}
