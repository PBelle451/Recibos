import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';
import 'package:provider/provider.dart';
import 'package:recibos/model/patient.dart';
import 'package:recibos/model/professional.dart';
import 'package:recibos/model/receipt.dart';
import 'package:recibos/model/user.dart';
import 'package:recibos/provider/receipts_provider.dart';
import 'package:recibos/screen/receipts_by_customer.dart';
import 'receipts_by_customer_test.mock.dart';

@GenerateNiceMocks([MockSpec<ReceiptsProvider>()])
void main() {

  testWidgets("Verifica se tela de listar recibos possui uma lista de recibos",
          (WidgetTester tester) async {
        MockReceiptsProvider mockReceiptsProvider = MockReceiptsProvider();
        Receipt receipt1 = Receipt(
          user: User(id: "1", email: "lucas@linard.tech", name: "Lucas Linard"),
          worker: Worker(name: "Pedro", cpf: "123456789", crm: "123456-df", signature: "Assinatura"),
          pacient: Patient(name: "Lara", rg: "321654987", cpf: "95720235353", endereco: "rua das pedras"),
          date: DateTime.now(),
          description: "Descrição",
          numberOfSessions: 1,
          value: 100,
        );

        mockReceiptsProvider.receipts = [
          receipt1
        ];

        MultiProvider app = MultiProvider(
          providers: [
            ChangeNotifierProvider<ReceiptsProvider>(
                create: (context) => mockReceiptsProvider)
          ],
          child: const MaterialApp(home: ReceiptsByCustomerScreen()),
        );
        await tester.pumpWidget(app);
        expect(find.byKey(const Key("ReceiptsList")), findsOneWidget);
      });

  testWidgets("Verifica se tela de listar recibos apresenta dois recibos",
          (WidgetTester tester) async {
        Receipt receipt1 = Receipt(
          user: User(id: "1", email: "lucas@linard.tech", name: "Lucas Linard"),
          worker: Worker(name: "Pedro", cpf: "123456789", crm: "123456-df", signature: "Assinatura"),
          pacient: Patient(name: "Lara", rg: "321654987", cpf: "95720235353", endereco: "rua das pedras"),
          date: DateTime.now(),
          description: "Descrição",
          numberOfSessions: 1,
          value: 100,
        );
        Receipt receipt2 = Receipt(
          user: User(id: "2", email: "lucas@linard.tech", name: "Lucas Linard"),
          worker: Worker(name: "Pedro", cpf: "123456789", crm: "123456-df", signature: "Assinatura"),
          pacient: Patient(name: "Lara", rg: "321654987", cpf: "95720235353", endereco: "rua das pedras"),
          date: DateTime.now(),
          description: "Descrição",
          numberOfSessions: 1,
          value: 300,
        );

        MockReceiptsProvider mockReceiptsProvider = MockReceiptsProvider();
        when(mockReceiptsProvider.receipts).thenReturn([receipt1, receipt2]);

        MultiProvider app = MultiProvider(
          providers: [
            ChangeNotifierProvider<ReceiptsProvider>(
                create: (context) => mockReceiptsProvider)
          ],
          child: const MaterialApp(home: ReceiptsByCustomerScreen()),
        );
        await tester.pumpWidget(app);
        expect(find.byKey(const Key("ReceiptsList")), findsOneWidget);
        expect(find.byType(ListTile), findsAtLeastNWidgets(2));
      });

  testWidgets("Verifica se tela de listar recibos possui uma Appbar",
          (WidgetTester tester) async {
        MultiProvider app = MultiProvider(
          providers: [
            ChangeNotifierProvider<ReceiptsProvider>(
                create: (context) => MockReceiptsProvider())
          ],
          child: const MaterialApp(home: ReceiptsByCustomerScreen()),
        );
        await tester.pumpWidget(app);
        expect(find.byKey(const Key("AppbarTelaReceiptsByCustomerScreen")), findsOneWidget);
      });
}
