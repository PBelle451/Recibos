import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/annotations.dart';
import 'package:provider/provider.dart';
import 'package:recibos/provider/receipts_provider.dart';
import 'package:recibos/screen/receipts_by_customer.dart';

import 'receipts_by_customer_test.mock.dart';

@GenerateNiceMocks([MockSpec<ReceiptsProvider>()])
void main() {
  testWidgets("Verifica se tela de listar recibos possui uma lista de recibos",
          (WidgetTester tester) async {
        MultiProvider app = MultiProvider(
          providers: [
            ChangeNotifierProvider<ReceiptsProvider>(
                create: (context) => MockReceiptsProvider())
          ],
          child: const MaterialApp(home: ReceiptsByCustomerScreen()),
        );
        await tester.pumpWidget(app);
        expect(find.byKey(const Key("ReceiptsList")), findsOneWidget);
      });

  testWidgets("Verifica se tela de listar recibos possui uma Appbar",
          (WidgetTester tester) async {
        MultiProvider app = MultiProvider(
          providers: [
            ChangeNotifierProvider<ReceiptsProvider>(
                create: (context) => MockReceiptsProvider())
          ],
          child: const MaterialApp(home: ReceiptsByCustomerScreen()),
        );
        await tester.pumpWidget(app);

      });
}
