package com.example.recibos

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
